package lab4burak;

import java.text.DecimalFormat;

public class Home extends Policy {
	
		private int squareFootage;
		private double dwelling;
		private double contents;
		private double liability;
		
		DecimalFormat df = new DecimalFormat("$###,###.00");
		
	public Home(String firstName, String lastName, int squareFootage, double dwelling, double contents, double liability) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.squareFootage = squareFootage;
		this.dwelling = dwelling;
		this.contents = contents;
		this.liability = liability;
		}

	public double computeCommission() {
		return (liability * 0.30) + ((dwelling + contents) * 0.20);
		   }

	//Getters/Setters	
	public int getSquareFootage() {
		return squareFootage;
	}

	public void setSquareFootage(int squareFootage) {
		this.squareFootage = squareFootage;
	}

	public double getDwelling() {
		return dwelling;
	}

	public void setDwelling(double dwelling) {
		this.dwelling = dwelling;
	}

	public double getContents() {
		return contents;
	}

	public void setContents(double contents) {
		this.contents = contents;
	}

	public double getLiability() {
		return liability;
	}

	public void setLiability(double liability) {
		this.liability = liability;
	}

	@Override
	public String toString() {
		return "Home Policy:\n-----------\nFootage: " + squareFootage + "\nDwelling: " + df.format(dwelling) + "\nContents:" + df.format(contents)
				+ "\nLiability: " + df.format(liability) + "\nCommission: " + df.format(this.computeCommission()) + "\n\n";
	}

	public void printPolicy() {
		System.out.printf("Home Policy%n-----------%nName: %s %s%nFootage: %d%nDwelling: $%,.2f%nContents: $%,.2f%nLiability: $%,.2f%nCommission: $%,.2f%n%n",
				firstName, lastName, squareFootage, dwelling, contents, liability, computeCommission());
		    }
		}
