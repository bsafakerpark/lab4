package lab4burak;

import java.text.DecimalFormat;

public class Life extends Policy {
		
			private int age;
			private double term;
			
			DecimalFormat df = new DecimalFormat("$###,###.00");
			
		public Life(String firstName, String lastName, int age, double term) {
			this.firstName = firstName;
			this.lastName = lastName;
			this.age = age;
			this.term = term;
			}

		public double computeCommission() {
			return term * 0.20;  
			    }

		public int getAge() {
			return age;
		}

		public void setAge(int age) {
			this.age = age;
		}

		public double getTerm() {
			return term;
		}

		public void setTerm(double term) {
			this.term = term;
		}
		
		

		@Override
		public String toString() {
			return "Life Policy\n-----------\nAge: " + age + "\nTerm: " + df.format(term) + "\nCommission: " + df.format(this.computeCommission()) + "\n\n";
		}

		public void printPolicy() {
			System.out.printf("Life Policy%n-----------%nName: %s %s%nAge: %d%nTerm: $%,.2f%nCommission: $%,.2f%n%n",
					firstName, lastName, age, term, computeCommission());
			    }
			}



